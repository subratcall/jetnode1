import streamlit as st
import pandas as pd
from PIL import Image
import numpy as np
import os
import cx_Oracle
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(rc={'axes.facecolor':'cornflowerblue', 'figure.facecolor':'cornflowerblue'})
os.environ["PATH"] += os.pathsep + "C:\\Users\\subparid\\Downloads\\instantclient\\instantclient_21_6"
os.environ['TNS_ADMIN'] = "C:\\Users\\subparid\\Downloads\\instantclient\\instantclient_21_6\\network\\admin"
connection = cx_Oracle.connect("admin", "Subrat123456789", "subratdw_high")

class DataAnnotation:
    class Model:
        pageTitle = "Product Details"

    def view(self, model):
        st.title(model.pageTitle)
        
        with st.container():
            col1, col2, col3, col4 = st.columns(4)

            with col1:
                st.metric(label="BAG SNACKS", value="33%", delta="125")

            with col2:
                st.metric(label="COLD CEREAL", value="22%", delta="-2")

            with col3:
                st.metric(label="FROZEN PIZZA", value="34.9%", delta="0.1%")

            with col4:
                st.metric(label="ORAL HYGIENE", value="11%", delta="10 mins", delta_color="inverse")

            st.markdown("---")
        
        image = Image.open('Corr_HHS.png')
        st.image(image, caption='Correlation Graph')
        
        with st.container():
            st.write("## Product Category Wise sell")
            df_prod=pd.read_sql("select category as Product_Category,sum(units) as Total_UNITs_SOLD from dh_transactions_analysis group by category",connection)
            fig = plt.figure(figsize=(20,5))
            sns.barplot(x=df_prod["PRODUCT_CATEGORY"], y=df_prod["TOTAL_UNITS_SOLD"])
            #arr = np.random.normal(1, 1, size=100)
            #fig, ax = plt.subplots()
            #aixo.hist(arr, bins=20)
            st.pyplot(fig)         