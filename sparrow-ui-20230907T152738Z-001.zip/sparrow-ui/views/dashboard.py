import streamlit as st
import numpy as np
import pandas as pd
import os
import cx_Oracle
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
sns.set(rc={'axes.facecolor':'cornflowerblue', 'figure.facecolor':'cornflowerblue'})
os.environ["PATH"] += os.pathsep + "C:\\Users\\subparid\\Downloads\\instantclient\\instantclient_21_6"
os.environ['TNS_ADMIN'] = "C:\\Users\\subparid\\Downloads\\instantclient\\instantclient_21_6\\network\\admin"
connection = cx_Oracle.connect("admin", "Subrat123456789", "subratdw_high")


class Dashboard:
    class Model:
        pageTitle = "Dashboard"

    def view(self, model):
        st.title(model.pageTitle)

        with st.container():
            col1, col2, col3, col4, col5 = st.columns(5)

            with col1:
                st.metric(label="Feature & Display", value="15%", delta="125")

            with col2:
                st.metric(label="Feature", value="5%", delta="2")

            with col3:
                st.metric(label="Display", value="6%", delta="0.1%")

            with col4:
                st.metric(label="TPR_Only", value="0.2%", delta="10", delta_color="inverse")

            with col5:
                st.metric(label="No Promo", value="-0%", delta="0", delta_color="inverse")

            st.markdown("---")
           


        with st.container():
            st.write("## Different Promo Performance")
            #monthly_unit_2009=pd.read_sql("select monthyear,sum(units) as cnt from dh_transactions_analysis where year=2009 group by monthyear order by monthyear",connection)
            #chart_data = pd.DataFrame(
            #    np.random.randn(20, 3),
            #    columns=['a', 'b', 'c'])
            #chart_data=monthly_unit_2009,['a', 'b', 'c']
            #unit=pd.read_sql("select week_end_date,promo,units from dh_transactions_analysis",connection)
            #df = pd.DataFrame(monthly_unit_2009.astype(str),columns=['MONTHYEAR', 'CNT'])
            #unit['UNIT_LOG']=np.log(unit['UNITS'])
            #values = ['Feature', 'Display', 'Feature_And_Display', 'Tpr_Only', 'No_Promo']
            #plt.figure(figsize=(10,8))
            #sns.boxplot(x='PROMO', y='UNIT_LOG', data=unit )
            #elasticity=pd.read_sql("select UNITS,PRICE,CATEGORY from dh_transactions_analysis",connection)
            #fig, axes = plt.subplots(2,2)
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='BAG SNACKS'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[0,0]).set_title('Bag Snacks')
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='COLD CEREAL'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[0,1]).set_title('Cold Cereal')
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='FROZEN PIZZA'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[1,0]).set_title('Frozen Pizza')
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='ORAL HYGIENE PRODUCTS'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[1,1]).set_title('Oral Hygiene')
            #fig.set_size_inches(13, 12)
            #st.pyplot(plt)
        image = Image.open('promo1.png')
        st.image(image, caption='')
        st.markdown("---")
        
        with st.container():
            st.write("## Price Elasticity")
            #monthly_unit_2009=pd.read_sql("select monthyear,sum(units) as cnt from dh_transactions_analysis where year=2009 group by monthyear order by monthyear",connection)
            #chart_data = pd.DataFrame(
            #    np.random.randn(20, 3),
            #    columns=['a', 'b', 'c'])
            #chart_data=monthly_unit_2009,['a', 'b', 'c']
            #unit=pd.read_sql("select week_end_date,promo,units from dh_transactions_analysis",connection)
            #df = pd.DataFrame(monthly_unit_2009.astype(str),columns=['MONTHYEAR', 'CNT'])
            #unit['UNIT_LOG']=np.log(unit['UNITS'])
            #values = ['Feature', 'Display', 'Feature_And_Display', 'Tpr_Only', 'No_Promo']
            #plt.figure(figsize=(10,8))
            #sns.boxplot(x='PROMO', y='UNIT_LOG', data=unit )
            #elasticity=pd.read_sql("select UNITS,PRICE,CATEGORY from dh_transactions_analysis",connection)
            #fig, axes = plt.subplots(2,2)
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='BAG SNACKS'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[0,0]).set_title('Bag Snacks')
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='COLD CEREAL'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[0,1]).set_title('Cold Cereal')
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='FROZEN PIZZA'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[1,0]).set_title('Frozen Pizza')
            #sns.regplot(x='PRICE', y='UNITS', data=elasticity.loc[elasticity['CATEGORY']=='ORAL HYGIENE PRODUCTS'], scatter_kws={'alpha':0.5}, line_kws={'color': 'r'}, ax=axes[1,1]).set_title('Oral Hygiene')
            #fig.set_size_inches(13, 12)
            #st.pyplot(plt)
        image = Image.open('Price1.png')
        st.image(image, caption='Price Elasticity')
                
        
        
        with st.container():
            st.write("## Correlation between HHS , VISIT and UNITS ")
            total_sales_visitors_hhs=pd.read_sql("select WEEKENDDATE,TOTAL_UNITS_SOLD,TOTAL_VISITORS,TOTAL_HOUSEHOLD from total_sales_visitor_hhs",connection)
            fig = plt.figure(figsize=(20,5))
            sns.lineplot(x='WEEKENDDATE', y='TOTAL_UNITS_SOLD',data=total_sales_visitors_hhs, markers=True)
            sns.lineplot(x='WEEKENDDATE', y='TOTAL_VISITORS',data=total_sales_visitors_hhs)
            sns.lineplot(x='WEEKENDDATE', y='TOTAL_HOUSEHOLD',data=total_sales_visitors_hhs)
            #arr = np.random.normal(1, 1, size=100)
            #fig, ax = plt.subplots()
            #aixo.hist(arr, bins=20)
            st.pyplot(fig)
            
        with st.container():
            st.write("## Price Trend over MonthYear")  
        image = Image.open('Price2.png')
        st.image(image, caption='Price Trend') 

        with st.container():
            st.write("## Spending Trend over MonthYear")  
        image = Image.open('Price3.png')
        st.image(image, caption='Spending Trend')        