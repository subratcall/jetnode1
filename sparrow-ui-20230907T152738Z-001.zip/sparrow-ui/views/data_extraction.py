import streamlit as st


class DataExtraction:
    class Model:
        pageTitle = "We will show you the insight Soon"

    def view(self, model):
        st.title(model.pageTitle)
