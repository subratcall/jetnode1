import streamlit as st
import numpy as np
import pandas as pd
import os
import cx_Oracle
import matplotlib.pyplot as plt
import seaborn as sns
os.environ["PATH"] += os.pathsep + "C:\\Users\\subparid\\Downloads\\instantclient\\instantclient_21_6"
os.environ['TNS_ADMIN'] = "C:\\Users\\subparid\\Downloads\\instantclient\\instantclient_21_6\\network\\admin"
connection = cx_Oracle.connect("admin", "Subrat123456789", "subratdw_high")


class ModelTraining:
    class Model:
        pageTitle = "Store Analysis"

    def view(self, model):
        st.title(model.pageTitle)


        with st.container():
            st.write("## Stores per city")
            df_store=pd.read_sql("select address_state_prov_code as state,avg_weekly_baskets,SALES_AREA_SIZE_NUM,seg_value_name from dh_stores",connection)
            fig = plt.figure(figsize=(20,5))
            #sns.lineplot(x='WEEKENDDATE', y='TOTAL_UNITS_SOLD',data=total_sales_visitors_hhs, markers=True)
            #sns.lineplot(x='WEEKENDDATE', y='TOTAL_VISITORS',data=total_sales_visitors_hhs)
            #sns.lineplot(x='WEEKENDDATE', y='TOTAL_HOUSEHOLD',data=total_sales_visitors_hhs)
            #arr = np.random.normal(1, 1, size=100)
            #fig, ax = plt.subplots()
            #aixo.hist(arr, bins=20)
            #sns.displot(x='SALES_AREA_SIZE_NUM', df_store,kind='kde')
            sns.countplot('SEG_VALUE_NAME', data=df_store )
            st.pyplot(fig)
            
        with st.container():
            st.write("## State wise Store and Weekly avarage basket count")
            df_store=pd.read_sql("select address_state_prov_code as state,avg_weekly_baskets,SALES_AREA_SIZE_NUM,seg_value_name from dh_stores",connection)
            fig, (ax1, ax2) = plt.subplots(ncols=2)
            fig.set_size_inches(15, 5)
            sns.countplot('STATE', data=df_store, ax=ax1)
            sns.boxplot(x='STATE', y='AVG_WEEKLY_BASKETS', data=df_store, ax=ax2)
            #arr = np.random.normal(1, 1, size=100)
            #fig, ax = plt.subplots()
            #aixo.hist(arr, bins=20)
            st.pyplot(fig)  

        with st.container():
            st.write("## Store segment Vs Area and  Store segment Vs Weekly avarage basket count")
            df_store=pd.read_sql("select address_state_prov_code as state,avg_weekly_baskets,SALES_AREA_SIZE_NUM,seg_value_name from dh_stores",connection)
            fig, (ax1, ax2) = plt.subplots(ncols=2)
            fig.set_size_inches(15, 5)
            sns.boxplot(x='SEG_VALUE_NAME', y='SALES_AREA_SIZE_NUM', data=df_store, ax=ax1).set_title('Segment VS. Area Size')
            sns.boxplot(x='SEG_VALUE_NAME', y='AVG_WEEKLY_BASKETS', data=df_store, ax=ax2).set_title('Segment VS. Average Weekly Baskets')
            #arr = np.random.normal(1, 1, size=100)
            #fig, ax = plt.subplots()
            #aixo.hist(arr, bins=20)
            st.pyplot(fig)              